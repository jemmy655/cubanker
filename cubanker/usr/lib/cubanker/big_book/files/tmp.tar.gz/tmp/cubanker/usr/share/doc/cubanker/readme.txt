************** project documentation ******************
* All documentation is provided on line at:           *
*     http://bank-builder.wikidot.com                 *
*     http://www.communitybanker.org                  *
* There are also rudimentary man pages:               *
*     man cubanker                                    *
*     man cubankerwiki                                *
*                                                     *
* Feel free to contact us at info@communitybanker.org *
*******************************************************

