sudo rm *.deb
sudo dpkg --purge cubanker
sudo chown root:root -R cubanker
sudo dpkg --build cubanker cubanker-0.0.1.deb
sudo dpkg -i cubanker-0.0.1.deb


